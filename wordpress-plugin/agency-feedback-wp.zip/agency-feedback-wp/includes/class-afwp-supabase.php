<?php

if (!defined('ABSPATH')) {
    exit;
}

final class AFWP_Supabase
{
    public function __construct()
    {
    }

    public function is_configured(): bool
    {
        return false;
    }

    public function resolve_project(string $slug, string $embedPublicKey, bool $withPasscode = false): ?array
    {
        return null;
    }
}
